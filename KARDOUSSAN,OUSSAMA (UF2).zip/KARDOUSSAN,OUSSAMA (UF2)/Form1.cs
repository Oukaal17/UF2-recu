﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KARDOUSSAN_OUSSAMA__UF2_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Pintar();
            txJugador1.Enabled = false;
            txJugador2.Enabled = false;
            txMaquina1.Enabled = false;
            txMaquina2.Enabled = false;
        }


        int[,] barallaAT = new int[2, 10];
        Random rand = new Random();

        int[] jugador = new int[10];
        int[] maquina = new int[10];

        private void Pintar()
        {
            lbProva.Text = "";
            for (int i = 0; i < barallaAT.GetLength(0); i++)
            {
                for (int j = 0; j < barallaAT.GetLength(1); j++)
                {
                    barallaAT[i, j] = rand.Next(0, 7);
                    lbProva.Text = lbProva.Text + "{" + barallaAT[i, j] + "}";
                }
                lbProva.Text = lbProva.Text + Environment.NewLine;
            }
            for (int i=0; i<1; i++)
            {
                for (int j = 0; j < barallaAT.GetLength(1); j++)
                {
                    jugador[j] = barallaAT[0, j];
                    maquina[i] = barallaAT[0, j];
                    lbJugador.Text = lbJugador.Text + "{" + jugador[j] + "}";
                    lbMaquina.Text = lbMaquina.Text + "{" + maquina[i] + "}";
                }
                txJugador1.Text = txJugador1.Text + jugador[0];
                txJugador2.Text = txJugador2.Text + jugador[5];

                txMaquina1.Text = txMaquina1.Text + jugador[6];
                txMaquina2.Text = txMaquina2.Text + jugador[9];

                lbMaquina.Text = lbMaquina.Text;
                lbJugador.Text = lbJugador.Text;
            }
        }
        private void btDelante_Click(object sender, EventArgs e)
        {
            txJugador1.Text = "";
            txJugador2.Text = "";
            for (int i = 0; i < barallaAT.GetLength(1); i++)
            {

            }
            txJugador1.Text = txJugador1.Text + jugador;
                txJugador2.Text = txJugador2.Text + jugador;
        }
    }
}
