﻿
namespace KARDOUSSAN_OUSSAMA__UF2_
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txMaquina1 = new System.Windows.Forms.TextBox();
            this.txMaquina2 = new System.Windows.Forms.TextBox();
            this.txJugador2 = new System.Windows.Forms.TextBox();
            this.txJugador1 = new System.Windows.Forms.TextBox();
            this.btAtras = new System.Windows.Forms.Button();
            this.btDelante = new System.Windows.Forms.Button();
            this.btAtacar = new System.Windows.Forms.Button();
            this.btDefensar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbProva = new System.Windows.Forms.Label();
            this.lbMaquina = new System.Windows.Forms.Label();
            this.lbJugador = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txMaquina1
            // 
            this.txMaquina1.Location = new System.Drawing.Point(147, 12);
            this.txMaquina1.Multiline = true;
            this.txMaquina1.Name = "txMaquina1";
            this.txMaquina1.Size = new System.Drawing.Size(200, 64);
            this.txMaquina1.TabIndex = 0;
            // 
            // txMaquina2
            // 
            this.txMaquina2.Location = new System.Drawing.Point(147, 82);
            this.txMaquina2.Multiline = true;
            this.txMaquina2.Name = "txMaquina2";
            this.txMaquina2.Size = new System.Drawing.Size(200, 64);
            this.txMaquina2.TabIndex = 1;
            // 
            // txJugador2
            // 
            this.txJugador2.Location = new System.Drawing.Point(141, 238);
            this.txJugador2.Multiline = true;
            this.txJugador2.Name = "txJugador2";
            this.txJugador2.Size = new System.Drawing.Size(200, 64);
            this.txJugador2.TabIndex = 3;
            // 
            // txJugador1
            // 
            this.txJugador1.Location = new System.Drawing.Point(141, 168);
            this.txJugador1.Multiline = true;
            this.txJugador1.Name = "txJugador1";
            this.txJugador1.Size = new System.Drawing.Size(200, 64);
            this.txJugador1.TabIndex = 2;
            // 
            // btAtras
            // 
            this.btAtras.Location = new System.Drawing.Point(60, 159);
            this.btAtras.Name = "btAtras";
            this.btAtras.Size = new System.Drawing.Size(75, 134);
            this.btAtras.TabIndex = 4;
            this.btAtras.Text = "<";
            this.btAtras.UseVisualStyleBackColor = true;
            // 
            // btDelante
            // 
            this.btDelante.Location = new System.Drawing.Point(347, 138);
            this.btDelante.Name = "btDelante";
            this.btDelante.Size = new System.Drawing.Size(75, 134);
            this.btDelante.TabIndex = 5;
            this.btDelante.Text = ">";
            this.btDelante.UseVisualStyleBackColor = true;
            this.btDelante.Click += new System.EventHandler(this.btDelante_Click);
            // 
            // btAtacar
            // 
            this.btAtacar.Location = new System.Drawing.Point(141, 324);
            this.btAtacar.Name = "btAtacar";
            this.btAtacar.Size = new System.Drawing.Size(200, 37);
            this.btAtacar.TabIndex = 6;
            this.btAtacar.Text = "Atacar";
            this.btAtacar.UseVisualStyleBackColor = true;
            // 
            // btDefensar
            // 
            this.btDefensar.Location = new System.Drawing.Point(141, 367);
            this.btDefensar.Name = "btDefensar";
            this.btDefensar.Size = new System.Drawing.Size(200, 37);
            this.btDefensar.TabIndex = 7;
            this.btDefensar.Text = "Defensar";
            this.btDefensar.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "MÀQUINA";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(34, 305);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "JUGADOR";
            // 
            // lbProva
            // 
            this.lbProva.AutoSize = true;
            this.lbProva.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbProva.Location = new System.Drawing.Point(384, 81);
            this.lbProva.Name = "lbProva";
            this.lbProva.Size = new System.Drawing.Size(0, 36);
            this.lbProva.TabIndex = 10;
            // 
            // lbMaquina
            // 
            this.lbMaquina.AutoSize = true;
            this.lbMaquina.Location = new System.Drawing.Point(21, 41);
            this.lbMaquina.Name = "lbMaquina";
            this.lbMaquina.Size = new System.Drawing.Size(0, 13);
            this.lbMaquina.TabIndex = 11;
            // 
            // lbJugador
            // 
            this.lbJugador.AutoSize = true;
            this.lbJugador.Location = new System.Drawing.Point(12, 324);
            this.lbJugador.Name = "lbJugador";
            this.lbJugador.Size = new System.Drawing.Size(0, 13);
            this.lbJugador.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(819, 405);
            this.Controls.Add(this.lbJugador);
            this.Controls.Add(this.lbMaquina);
            this.Controls.Add(this.lbProva);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btDefensar);
            this.Controls.Add(this.btAtacar);
            this.Controls.Add(this.btDelante);
            this.Controls.Add(this.btAtras);
            this.Controls.Add(this.txJugador2);
            this.Controls.Add(this.txJugador1);
            this.Controls.Add(this.txMaquina2);
            this.Controls.Add(this.txMaquina1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txMaquina1;
        private System.Windows.Forms.TextBox txMaquina2;
        private System.Windows.Forms.TextBox txJugador2;
        private System.Windows.Forms.TextBox txJugador1;
        private System.Windows.Forms.Button btAtras;
        private System.Windows.Forms.Button btDelante;
        private System.Windows.Forms.Button btAtacar;
        private System.Windows.Forms.Button btDefensar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbProva;
        private System.Windows.Forms.Label lbMaquina;
        private System.Windows.Forms.Label lbJugador;
    }
}

