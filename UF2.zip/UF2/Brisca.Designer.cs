﻿
namespace UF2
{
    partial class Brisca
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txCartesJ1 = new System.Windows.Forms.TextBox();
            this.txCartesJ2 = new System.Windows.Forms.TextBox();
            this.btIniciar = new System.Windows.Forms.Button();
            this.btJ1C1 = new System.Windows.Forms.Button();
            this.btJ1C2 = new System.Windows.Forms.Button();
            this.btJ1C3 = new System.Windows.Forms.Button();
            this.btJ2C3 = new System.Windows.Forms.Button();
            this.btJ2C2 = new System.Windows.Forms.Button();
            this.btJ2C1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txCartesJ1
            // 
            this.txCartesJ1.Location = new System.Drawing.Point(12, 12);
            this.txCartesJ1.Multiline = true;
            this.txCartesJ1.Name = "txCartesJ1";
            this.txCartesJ1.Size = new System.Drawing.Size(238, 84);
            this.txCartesJ1.TabIndex = 0;
            // 
            // txCartesJ2
            // 
            this.txCartesJ2.Location = new System.Drawing.Point(284, 12);
            this.txCartesJ2.Multiline = true;
            this.txCartesJ2.Name = "txCartesJ2";
            this.txCartesJ2.Size = new System.Drawing.Size(237, 84);
            this.txCartesJ2.TabIndex = 1;
            // 
            // btIniciar
            // 
            this.btIniciar.Location = new System.Drawing.Point(205, 279);
            this.btIniciar.Name = "btIniciar";
            this.btIniciar.Size = new System.Drawing.Size(75, 23);
            this.btIniciar.TabIndex = 2;
            this.btIniciar.Text = "START";
            this.btIniciar.UseVisualStyleBackColor = true;
            // 
            // btJ1C1
            // 
            this.btJ1C1.Location = new System.Drawing.Point(13, 103);
            this.btJ1C1.Name = "btJ1C1";
            this.btJ1C1.Size = new System.Drawing.Size(75, 91);
            this.btJ1C1.TabIndex = 3;
            this.btJ1C1.Text = "CARTA 1";
            this.btJ1C1.UseVisualStyleBackColor = true;
            // 
            // btJ1C2
            // 
            this.btJ1C2.Location = new System.Drawing.Point(94, 103);
            this.btJ1C2.Name = "btJ1C2";
            this.btJ1C2.Size = new System.Drawing.Size(75, 91);
            this.btJ1C2.TabIndex = 4;
            this.btJ1C2.Text = "CARTA 2";
            this.btJ1C2.UseVisualStyleBackColor = true;
            // 
            // btJ1C3
            // 
            this.btJ1C3.Location = new System.Drawing.Point(175, 103);
            this.btJ1C3.Name = "btJ1C3";
            this.btJ1C3.Size = new System.Drawing.Size(75, 91);
            this.btJ1C3.TabIndex = 5;
            this.btJ1C3.Text = "CARTA 3";
            this.btJ1C3.UseVisualStyleBackColor = true;
            // 
            // btJ2C3
            // 
            this.btJ2C3.Location = new System.Drawing.Point(446, 102);
            this.btJ2C3.Name = "btJ2C3";
            this.btJ2C3.Size = new System.Drawing.Size(75, 91);
            this.btJ2C3.TabIndex = 8;
            this.btJ2C3.Text = "CARTA 3";
            this.btJ2C3.UseVisualStyleBackColor = true;
            // 
            // btJ2C2
            // 
            this.btJ2C2.Location = new System.Drawing.Point(365, 103);
            this.btJ2C2.Name = "btJ2C2";
            this.btJ2C2.Size = new System.Drawing.Size(75, 91);
            this.btJ2C2.TabIndex = 7;
            this.btJ2C2.Text = "CARTA 2";
            this.btJ2C2.UseVisualStyleBackColor = true;
            // 
            // btJ2C1
            // 
            this.btJ2C1.Location = new System.Drawing.Point(282, 103);
            this.btJ2C1.Name = "btJ2C1";
            this.btJ2C1.Size = new System.Drawing.Size(75, 91);
            this.btJ2C1.TabIndex = 6;
            this.btJ2C1.Text = "CARTA 1";
            this.btJ2C1.UseVisualStyleBackColor = true;
            // 
            // Brisca
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(581, 314);
            this.Controls.Add(this.btJ2C3);
            this.Controls.Add(this.btJ2C2);
            this.Controls.Add(this.btJ2C1);
            this.Controls.Add(this.btJ1C3);
            this.Controls.Add(this.btJ1C2);
            this.Controls.Add(this.btJ1C1);
            this.Controls.Add(this.btIniciar);
            this.Controls.Add(this.txCartesJ2);
            this.Controls.Add(this.txCartesJ1);
            this.Name = "Brisca";
            this.Text = "Brisca";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txCartesJ1;
        private System.Windows.Forms.TextBox txCartesJ2;
        private System.Windows.Forms.Button btIniciar;
        private System.Windows.Forms.Button btJ1C1;
        private System.Windows.Forms.Button btJ1C2;
        private System.Windows.Forms.Button btJ1C3;
        private System.Windows.Forms.Button btJ2C3;
        private System.Windows.Forms.Button btJ2C2;
        private System.Windows.Forms.Button btJ2C1;
    }
}