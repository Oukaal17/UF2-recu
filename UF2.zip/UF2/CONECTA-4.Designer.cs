﻿
namespace UF2
{
    partial class CONECTA_4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txTauler = new System.Windows.Forms.TextBox();
            this.btJuga1 = new System.Windows.Forms.Button();
            this.btC1 = new System.Windows.Forms.Button();
            this.btC2 = new System.Windows.Forms.Button();
            this.btC3 = new System.Windows.Forms.Button();
            this.btC4 = new System.Windows.Forms.Button();
            this.btC5 = new System.Windows.Forms.Button();
            this.btC6 = new System.Windows.Forms.Button();
            this.btC7 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txTauler
            // 
            this.txTauler.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txTauler.Cursor = System.Windows.Forms.Cursors.Hand;
            this.txTauler.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txTauler.Location = new System.Drawing.Point(13, 13);
            this.txTauler.Multiline = true;
            this.txTauler.Name = "txTauler";
            this.txTauler.Size = new System.Drawing.Size(256, 338);
            this.txTauler.TabIndex = 0;
            // 
            // btJuga1
            // 
            this.btJuga1.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btJuga1.Location = new System.Drawing.Point(309, 13);
            this.btJuga1.Name = "btJuga1";
            this.btJuga1.Size = new System.Drawing.Size(170, 164);
            this.btJuga1.TabIndex = 1;
            this.btJuga1.Text = "PLAY !";
            this.btJuga1.UseVisualStyleBackColor = true;
            this.btJuga1.Click += new System.EventHandler(this.btJuga1_Click);
            // 
            // btC1
            // 
            this.btC1.Location = new System.Drawing.Point(23, 226);
            this.btC1.Name = "btC1";
            this.btC1.Size = new System.Drawing.Size(17, 115);
            this.btC1.TabIndex = 2;
            this.btC1.Text = "1";
            this.btC1.UseVisualStyleBackColor = true;
            this.btC1.Click += new System.EventHandler(this.btC1_Click);
            // 
            // btC2
            // 
            this.btC2.Location = new System.Drawing.Point(51, 226);
            this.btC2.Name = "btC2";
            this.btC2.Size = new System.Drawing.Size(16, 115);
            this.btC2.TabIndex = 3;
            this.btC2.Text = "2";
            this.btC2.UseVisualStyleBackColor = true;
            this.btC2.Click += new System.EventHandler(this.btC2_Click);
            // 
            // btC3
            // 
            this.btC3.Location = new System.Drawing.Point(73, 226);
            this.btC3.Name = "btC3";
            this.btC3.Size = new System.Drawing.Size(16, 115);
            this.btC3.TabIndex = 4;
            this.btC3.Text = "3";
            this.btC3.UseVisualStyleBackColor = true;
            this.btC3.Click += new System.EventHandler(this.btC3_Click);
            // 
            // btC4
            // 
            this.btC4.Location = new System.Drawing.Point(100, 226);
            this.btC4.Name = "btC4";
            this.btC4.Size = new System.Drawing.Size(16, 115);
            this.btC4.TabIndex = 5;
            this.btC4.Text = "4";
            this.btC4.UseVisualStyleBackColor = true;
            this.btC4.Click += new System.EventHandler(this.btC4_Click);
            // 
            // btC5
            // 
            this.btC5.Location = new System.Drawing.Point(123, 226);
            this.btC5.Name = "btC5";
            this.btC5.Size = new System.Drawing.Size(16, 115);
            this.btC5.TabIndex = 6;
            this.btC5.Text = "5";
            this.btC5.UseVisualStyleBackColor = true;
            this.btC5.Click += new System.EventHandler(this.btC5_Click);
            // 
            // btC6
            // 
            this.btC6.Location = new System.Drawing.Point(149, 226);
            this.btC6.Name = "btC6";
            this.btC6.Size = new System.Drawing.Size(17, 115);
            this.btC6.TabIndex = 7;
            this.btC6.Text = "6";
            this.btC6.UseVisualStyleBackColor = true;
            this.btC6.Click += new System.EventHandler(this.btC6_Click);
            // 
            // btC7
            // 
            this.btC7.Location = new System.Drawing.Point(176, 226);
            this.btC7.Name = "btC7";
            this.btC7.Size = new System.Drawing.Size(15, 115);
            this.btC7.TabIndex = 8;
            this.btC7.Text = "7";
            this.btC7.UseVisualStyleBackColor = true;
            this.btC7.Click += new System.EventHandler(this.btC7_Click);
            // 
            // CONECTA_4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 373);
            this.Controls.Add(this.btC7);
            this.Controls.Add(this.btC6);
            this.Controls.Add(this.btC5);
            this.Controls.Add(this.btC4);
            this.Controls.Add(this.btC3);
            this.Controls.Add(this.btC2);
            this.Controls.Add(this.btC1);
            this.Controls.Add(this.btJuga1);
            this.Controls.Add(this.txTauler);
            this.Name = "CONECTA_4";
            this.Text = "CONECTA_4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txTauler;
        private System.Windows.Forms.Button btJuga1;
        private System.Windows.Forms.Button btC1;
        private System.Windows.Forms.Button btC2;
        private System.Windows.Forms.Button btC3;
        private System.Windows.Forms.Button btC4;
        private System.Windows.Forms.Button btC5;
        private System.Windows.Forms.Button btC6;
        private System.Windows.Forms.Button btC7;
    }
}