﻿
namespace UF2
{
    partial class Form7_5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txCartesJ1 = new System.Windows.Forms.TextBox();
            this.txCartesJ2 = new System.Windows.Forms.TextBox();
            this.txSortida = new System.Windows.Forms.TextBox();
            this.btCartaJ1 = new System.Windows.Forms.Button();
            this.btStopJ1 = new System.Windows.Forms.Button();
            this.btCartaJ2 = new System.Windows.Forms.Button();
            this.btStopJ2 = new System.Windows.Forms.Button();
            this.btIniciar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txPuntsJ1 = new System.Windows.Forms.TextBox();
            this.txPuntsJ2 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txCartesJ1
            // 
            this.txCartesJ1.Location = new System.Drawing.Point(13, 40);
            this.txCartesJ1.Multiline = true;
            this.txCartesJ1.Name = "txCartesJ1";
            this.txCartesJ1.Size = new System.Drawing.Size(124, 114);
            this.txCartesJ1.TabIndex = 0;
            // 
            // txCartesJ2
            // 
            this.txCartesJ2.Location = new System.Drawing.Point(174, 40);
            this.txCartesJ2.Multiline = true;
            this.txCartesJ2.Name = "txCartesJ2";
            this.txCartesJ2.Size = new System.Drawing.Size(124, 114);
            this.txCartesJ2.TabIndex = 1;
            // 
            // txSortida
            // 
            this.txSortida.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txSortida.Location = new System.Drawing.Point(318, 40);
            this.txSortida.Multiline = true;
            this.txSortida.Name = "txSortida";
            this.txSortida.Size = new System.Drawing.Size(285, 143);
            this.txSortida.TabIndex = 2;
            // 
            // btCartaJ1
            // 
            this.btCartaJ1.Location = new System.Drawing.Point(16, 189);
            this.btCartaJ1.Name = "btCartaJ1";
            this.btCartaJ1.Size = new System.Drawing.Size(124, 23);
            this.btCartaJ1.TabIndex = 3;
            this.btCartaJ1.Text = "CARTA J1";
            this.btCartaJ1.UseVisualStyleBackColor = true;
            this.btCartaJ1.Click += new System.EventHandler(this.btCartaJ1_Click);
            // 
            // btStopJ1
            // 
            this.btStopJ1.Location = new System.Drawing.Point(16, 227);
            this.btStopJ1.Name = "btStopJ1";
            this.btStopJ1.Size = new System.Drawing.Size(124, 23);
            this.btStopJ1.TabIndex = 4;
            this.btStopJ1.Text = "STOP J1";
            this.btStopJ1.UseVisualStyleBackColor = true;
            this.btStopJ1.Click += new System.EventHandler(this.btStopJ1_Click);
            // 
            // btCartaJ2
            // 
            this.btCartaJ2.Location = new System.Drawing.Point(177, 189);
            this.btCartaJ2.Name = "btCartaJ2";
            this.btCartaJ2.Size = new System.Drawing.Size(124, 23);
            this.btCartaJ2.TabIndex = 5;
            this.btCartaJ2.Text = "CARTA J2";
            this.btCartaJ2.UseVisualStyleBackColor = true;
            this.btCartaJ2.Click += new System.EventHandler(this.btCartaJ2_Click);
            // 
            // btStopJ2
            // 
            this.btStopJ2.Location = new System.Drawing.Point(177, 227);
            this.btStopJ2.Name = "btStopJ2";
            this.btStopJ2.Size = new System.Drawing.Size(124, 23);
            this.btStopJ2.TabIndex = 6;
            this.btStopJ2.Text = "STOP J2";
            this.btStopJ2.UseVisualStyleBackColor = true;
            this.btStopJ2.Click += new System.EventHandler(this.btStopJ2_Click);
            // 
            // btIniciar
            // 
            this.btIniciar.Location = new System.Drawing.Point(16, 256);
            this.btIniciar.Name = "btIniciar";
            this.btIniciar.Size = new System.Drawing.Size(284, 33);
            this.btIniciar.TabIndex = 7;
            this.btIniciar.Text = "INICIAR";
            this.btIniciar.UseVisualStyleBackColor = true;
            this.btIniciar.Click += new System.EventHandler(this.btIniciar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "JUGADOR 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(207, 21);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(68, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "JUGADOR 2";
            // 
            // txPuntsJ1
            // 
            this.txPuntsJ1.Location = new System.Drawing.Point(16, 161);
            this.txPuntsJ1.Name = "txPuntsJ1";
            this.txPuntsJ1.Size = new System.Drawing.Size(121, 20);
            this.txPuntsJ1.TabIndex = 11;
            // 
            // txPuntsJ2
            // 
            this.txPuntsJ2.Location = new System.Drawing.Point(174, 160);
            this.txPuntsJ2.Name = "txPuntsJ2";
            this.txPuntsJ2.Size = new System.Drawing.Size(121, 20);
            this.txPuntsJ2.TabIndex = 12;
            // 
            // Form7_5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(617, 301);
            this.Controls.Add(this.txPuntsJ2);
            this.Controls.Add(this.txPuntsJ1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btIniciar);
            this.Controls.Add(this.btStopJ2);
            this.Controls.Add(this.btCartaJ2);
            this.Controls.Add(this.btStopJ1);
            this.Controls.Add(this.btCartaJ1);
            this.Controls.Add(this.txSortida);
            this.Controls.Add(this.txCartesJ2);
            this.Controls.Add(this.txCartesJ1);
            this.Name = "Form7_5";
            this.Text = "Form7_5";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txCartesJ1;
        private System.Windows.Forms.TextBox txCartesJ2;
        private System.Windows.Forms.TextBox txSortida;
        private System.Windows.Forms.Button btCartaJ1;
        private System.Windows.Forms.Button btStopJ1;
        private System.Windows.Forms.Button btCartaJ2;
        private System.Windows.Forms.Button btStopJ2;
        private System.Windows.Forms.Button btIniciar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txPuntsJ1;
        private System.Windows.Forms.TextBox txPuntsJ2;
    }
}